import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
/**
 * Write a description of class GUI here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GUI extends JFrame
{    
    private JPanel panel; 
    private JButton button1,button2;    
    private JLabel Label1, Label2,Label3,Label4,Label5,Label6;    
    private JLabel Label7, Label8,Label9,Label10,Label11,Label12;
    private JLabel Label13, Label14,Label15,Label16,Label17,Label18;
    private JTextField Text1, Text2, Text3,Text4,Text5,Text6;
    private JTextField Text7, Text8, Text9,Text10,Text11,Text12;
    private JTextField Text13, Text14, Text15,Text16,Text17,Text18;
    private final int WIDTH = 1000;
    private final int HEIGHT = 1000;
    //default 350 , 250
       public GUI()
    {
        
        setSize(WIDTH,HEIGHT);//int, int
        setTitle("Report");//string
        setDefaultCloseOperation(EXIT_ON_CLOSE);//int
        setLocation(WIDTH, HEIGHT); //int, int
        buildPanel();//call the buildpanel method
        add(panel);//add the panel
        
        //displays the window
        setVisible(true); //boolean
        
      
    }
   
    private void buildPanel()
    {
        panel = new JPanel();
        panel.setLayout(new GridLayout(7,2));
        
        button1= new JButton("Calaculate");
        button2= new JButton("Exit");
        
        //format the labels and textboxes
        
        Label1 = new JLabel( "Gas Furnace: ", JLabel.RIGHT);
        Label2 = new JLabel( "Capacity: ", JLabel.RIGHT);
        Label3 = new JLabel( "Efficiency: ", JLabel.RIGHT);
        Label4 = new JLabel( "Pilot On: ", JLabel.RIGHT);
        Label5 = new JLabel( "Heating: ", JLabel.RIGHT);
        Label6 = new JLabel( "Room: ", JLabel.RIGHT);
        Label7 = new JLabel( "YearBuilt: ", JLabel.RIGHT);
        Label8 = new JLabel( "Area(Sq Ft): ", JLabel.RIGHT);
        Label9 = new JLabel( "SHC: ", JLabel.RIGHT);
        Label10 = new JLabel( "BLC: ", JLabel.RIGHT);        
        Label11 = new JLabel( "Environment:  ", JLabel.RIGHT);
        Label12 = new JLabel( "Temperature: ", JLabel.RIGHT);
        Label13 = new JLabel( "Thermostat: ", JLabel.RIGHT);
        Label14 = new JLabel( "Setting: ", JLabel.RIGHT);
        Label15 = new JLabel( "Overheat: ", JLabel.RIGHT);
        Label16 = new JLabel( "Start Simulation: ", JLabel.RIGHT);
        Label17 = new JLabel( "Display Frequency (secs): ", JLabel.RIGHT);
        Label18 = new JLabel( "Runtime (secs): ", JLabel.RIGHT);
        
        Text1 = new JTextField (7);
        Text2 = new JTextField (7);
        Text3 = new JTextField (7);
        Text4 = new JTextField (7);
        Text5 = new JTextField (7);
        Text6 = new JTextField (7);
        Text7 = new JTextField (7);
        Text8 = new JTextField (7);
        Text9 = new JTextField (7);
        Text10 = new JTextField (7);
        Text11 = new JTextField (7);
        Text12 = new JTextField (7);
        Text13 = new JTextField (7);
        Text14 = new JTextField (7);
        Text15 = new JTextField (7);
        Text16= new JTextField (7);
        Text17= new JTextField (7);
        Text18 = new JTextField (7);
        
        panel.add(Label1);
        panel.add(Text1);   
        panel.add(Label2);
        panel.add(Text2);
        panel.add(Label3);
        panel.add(Text3);
        panel.add(Label4);
        panel.add(Text4);
        panel.add(Label5);
        panel.add(Text5);
        panel.add(Label6);
        panel.add(Text6);
        
        panel.add(Label7);
        panel.add(Text7);   
        panel.add(Label8);
        panel.add(Text8);
        panel.add(Label9);
        panel.add(Text9);
        panel.add(Label10);
        panel.add(Text10);
        panel.add(Label11);
        panel.add(Text11);
        panel.add(Label12);
        panel.add(Text12);
        
        panel.add(Label13);
        panel.add(Text13);   
        panel.add(Label14);
        panel.add(Text14);
        panel.add(Label15);
        panel.add(Text15);
        panel.add(Label16);
        panel.add(Text16);
        panel.add(Label17);
        panel.add(Text17);
        panel.add(Label18);
        panel.add(Text18);

        button1.addActionListener(new CalculateButtonListener());
        button2.addActionListener( new ExitButtonListener());
        
        panel.add(button1);
        panel.add(button2);
        
    }
        
    private class CalculateButtonListener implements ActionListener
    {
        public void actionPerformed (ActionEvent e)
        {
           //Call all the methods 
           // calculate and print into the forms
           // print into a textfile
        }
    }    
    private class ExitButtonListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         // Exit the application.
          System.exit(0);
      }
   }     
   }

